# 文件名：test_mcp_http_client.py

import asyncio
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

async def test():
    url = "http://127.0.0.1:8000/mcp"     # Server的HTTP地址
    # 第三个对象 _（被忽略的对象）： 这是跟底层网络传输（Transport）相关的元数据或回调函数。在流式 HTTP 的实现中，它通常是一个用来获取当前底层 HTTP 连接的 Session ID（会话标识） 的函数。
    # 除非你在写极其复杂的底层重连机制、或者需要追踪排查极端的网络断线日志，否则在日常调用工具开发 Agent 时根本用不到它
    async with streamable_http_client(url=url) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools = await session.list_tools()
            print("可用工具:", tools)

            result = await session.call_tool("add", {"a": 10, "b": 20})
            print("调用结果:", result)

asyncio.run(test())