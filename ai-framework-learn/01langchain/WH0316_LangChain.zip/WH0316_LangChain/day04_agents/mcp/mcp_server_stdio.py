
from mcp.server.fastmcp import FastMCP

# ===== 创建MCP Server实例 =====
mcp = FastMCP("MyTools")

# ===== 用 @mcp.tool() 定义工具 =====
# 注意：写法和LangChain的 @tool 非常相似
@mcp.tool()
def add(a: int, b: int) -> int:
    """计算两个整数的和"""
    return a + b

@mcp.tool()
def multiply(a: int, b: int) -> int:
    """计算两个整数的乘积"""
    return a * b

# ===== 启动Server =====
if __name__ == "__main__":
    mcp.run(transport="stdio")   # 以Stdio方式运行