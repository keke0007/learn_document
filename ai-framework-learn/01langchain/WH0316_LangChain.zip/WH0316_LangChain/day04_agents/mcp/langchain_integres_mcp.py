# uv add langchain-mcp-adapters

import os
import sys
import asyncio
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.checkpoint.memory import InMemorySaver
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()

# ===== 精准定位 Server 文件的绝对路径 =====
# 1. 获取当前脚本 (langchain_integration_mcp.py) 所在的目录
# D:\develop\develop\workspace\WH0316_LangChain\day04_agents\mcp\mcp_server_stdio.py
current_dir = os.path.dirname(os.path.abspath(__file__))

# 2. 向上退一级到 mcp 目录，然后进入 stdio 目录，找到 mcp_server_stdio.py
server_script_path = os.path.join(current_dir, "mcp_server_stdio.py")

print(f"准备调用的 Server 路径: {server_script_path}")

# ===== 第1步：配置MCP Server连接 =====
client = MultiServerMCPClient({
    # 连接一个本地Stdio Server
    "my-local-tools": {
        "transport": "stdio",
        "command": sys.executable,  # 使用当前虚拟环境的 Python
        "args": [server_script_path],  # 使用计算好的绝对路径
    },

    "12306-mcp": {
        "transport": "streamable_http",
        "url": "https://mcp.api-inference.modelscope.net/8e63d4dbeef046/mcp"
    }
})


# ===== 第2步：获取所有Server的工具，创建Agent =====
async def main():
    # 自动连接所有Server，获取全部工具列表
    tools = await client.get_tools()
    # print(tools)
    print(f"✅ 成功获取到 {len(tools)} 个工具")

    # # 此时tools里包含了Server的所有工具，和本地@tool定义的工具格式完全相同
    llm = ChatOpenAI(model="gpt-4o-mini")

    checkpointer = InMemorySaver()

    agent = create_agent(llm, tools, checkpointer=checkpointer)

    # # ===== 第3步：像平常一样使用Agent =====
    print("\n 开始执行Agent...")
    result = await agent.ainvoke({
        "messages": [("user", "武汉有多少个火车站")],
    },
        config={"configurable": {"thread_id": "user_张三"}},
    )

    # # 打印最终结果
    print("\n🤖 Agent回复:", result["messages"][-1].content)

    result1 = await agent.ainvoke({
        "messages": [("user", "我刚刚问了你什么问题")]
    },
        config={"configurable": {"thread_id": "user_张三"}},
    )
    # # 打印最终结果
    print("\n🤖 Agent回复:", result1["messages"][-1].content)


asyncio.run(main())
