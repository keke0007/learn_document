import asyncio
import sys
import os
from mcp.client.stdio import stdio_client
from mcp import ClientSession, StdioServerParameters

async def test():
    # 动态获取当前脚本所在的绝对路径所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 拼接出 server 脚本的绝对路径
    server_script_path = os.path.join(current_dir, "mcp_server_stdio.py")

    # 配置Server的启动命令
    server_params = StdioServerParameters(
        command=sys.executable,        #  1：使用当前跑Client的同一个Python解释器(虚拟环境)
        args=[server_script_path],     #  2：使用绝对路径
    )


    # 连接Server
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()       # 第②步：握手

            # 查看Server提供了哪些工具 它 只去拉取工具
            tools = await session.list_tools()
            print("可用工具:", tools)

            # 调用工具
            result = await session.call_tool("add", {"a": 10, "b": 20})
            print("调用结果:", result)        # 输出: 30

asyncio.run(test())