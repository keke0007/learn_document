def main():
    print("Hello from wh0316-langchain!")


if __name__ == "__main__":
    main()
