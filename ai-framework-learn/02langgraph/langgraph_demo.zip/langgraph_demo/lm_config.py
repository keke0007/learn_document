# lm_config.py

"""
定义模型参数配置类
"""

from dataclasses import dataclass
import os


# 定义minerU服务配置
@dataclass
class LLMConfig:
    llm_model: str
    model_provider: str
    base_url: str
    api_key : str

lm_config = LLMConfig(
    llm_model="qwen3.6-flash",
    model_provider="openai",
    base_url=os.getenv("DASHSCOPE_BASE_URL"),
    api_key=os.getenv("DASHSCOPE_API_KEY")
)