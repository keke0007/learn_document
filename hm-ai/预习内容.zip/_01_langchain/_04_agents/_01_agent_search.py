#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/1/4 16:44
@File    : _08_agent.py
@Function :
pip install -U ddgs
pip install numexpr
"""
# pip install duckduckgo-search

import os
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_community.tools import DuckDuckGoSearchRun

ddg_search = DuckDuckGoSearchRun()
# 实例化大模型
llm = ChatOpenAI(
    model="qwen-max",
    api_key=os.getenv('API_KEY'),
    base_url=os.getenv("BASE_URL"),
)

agent = create_agent(
    model=llm,
    tools=[ddg_search],
    system_prompt="""你是一个有用的个人助手，根据用户的输入内容选择对应的工具，解答用户的问题"""
)

print('agent', agent)

# 代理Agent工作
response = agent.invoke(
    {"messages": [
        {"role": "user", "content": "中国目前有多少人口"}
    ]}
)
for msg in response["messages"]:
    print(msg)

# for chunk in agent.stream(
#         {"messages": [
#             {"role": "user", "content": "2025年中国目前有多少人口"}
#         ]}
# ):
#     print(chunk)
