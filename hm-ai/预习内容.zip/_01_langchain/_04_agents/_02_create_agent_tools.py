#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/3/24 11:54
@File    : _02_create_agent_tools.py
@Function :
"""
from langchain.tools import tool
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI
import os
from langchain.agents import create_agent
import requests


@tool
def write_file(file_path: str, content: str):
    """
    把content写入文件路径file_path
    """
    with open(file_path, "w") as writer:
        writer.write(content)

    print(f"写入文件{file_path} 成功")


@tool
def multiply(a: int, b: int) -> int:
    """用于计算两个整数的乘积。"""
    print(f"正在执行乘法: {a} * {b}")
    return a * b


@tool
def add(a: int, b: int) -> int:
    """用于计算两个整数的乘积。"""
    print(f"正在执行加法: {a} * {b}")
    return a + b


llm = ChatOpenAI(
    model="qwen-flash",
    api_key=os.getenv('API_KEY'),
    base_url=os.getenv("BASE_URL"),
)


@tool
def get_weather(city: str):
    """查询城市天气"""
    url = "https://m459fcyb7c.re.qweatherapi.com/v7/weather/now"
    city_code_map = {
        "上海": "101020100",
        "北京": "101010100",
        "广州": "101280101",
        "深圳": "101280601",
    }
    response = requests.get(url, params={
        "location": city_code_map.get(city, "101280601"),
    }, headers={"X-QW-Api-Key": os.getenv("WEATHER_KEY")})
    # return f"{city} 当前天气：晴天 25℃"  # 模拟
    return response.json()


tools = [get_weather, add, multiply, write_file]

agent = create_agent(
    model=llm,
    tools=tools,
    system_prompt="你是系统助手，需要根据用户的输入决定是否调用工具完成任务"
)

# messages = agent.invoke({"messages": messages})
# for each in messages["messages"]:
#     print(each)

print(agent.invoke({"messages": HumanMessage(content="详细介绍下什么是langchain框架，写入本地文件，名字自己起一个")}))

messages = [{"role": "user", "content": "帮我算 5 * 6，然后查一下深圳的天气"}]

# 工具的流式返回
# for chunk in agent.stream({"messages": messages}):
#     print(chunk)
