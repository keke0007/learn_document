#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/3/26 11:49
@File    : _01_simple_chain.py
@Function :
"""

from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
import os

llm = ChatOpenAI(
    api_key=os.getenv("API_KEY"),
    model="qwen-max",
    base_url=os.getenv("BASE_URL")
)

prompt = PromptTemplate(
    template="我的邻居姓{lastname}，他生了个儿子，给他儿子起一个名字，起3个最好听的名字",
    input_variables=["lastname"],
)

chain = prompt | llm
print(chain.invoke({"lastname": "张"}).content)
