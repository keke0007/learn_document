#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/3/24 12:00
@File    : _01_message.py
@Function :
"""
from langchain.messages import HumanMessage, AIMessage
from langchain_openai import ChatOpenAI
import os

llm = ChatOpenAI(
    model="qwen-flash",
    api_key=os.getenv('API_KEY'),
    base_url=os.getenv("BASE_URL"),
)
messages = [
    HumanMessage(content="你好"),
    AIMessage(content="你好，有什么可以帮你？"),
    HumanMessage(content="LangChain 是什么？")
]

response = llm.invoke(messages)
print(response.content)
