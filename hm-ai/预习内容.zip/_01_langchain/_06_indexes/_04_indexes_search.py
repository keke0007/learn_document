#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/1/4 18:11
@File    : _16_indexes_search.py
@Function :
"""
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings import DashScopeEmbeddings
import os

loader = TextLoader('../data/pku.txt')
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=100, chunk_overlap=0)
texts = text_splitter.split_documents(documents)

embeddings = DashScopeEmbeddings(
    model="text-embedding-v1",  # text-embedding-v3
    dashscope_api_key=os.getenv('API_KEY')
)

db = Chroma.from_documents(texts, embeddings, persist_directory="outputs/Chroma.db")
retriever = db.as_retriever(search_kwargs={'k': 1})
docs = retriever.invoke("北京大学什么时候成立的")
print(docs)

# 打印结果：
'''
[Document(metadata={'source': 'data/pku.txt'}, page_content='北京大学创办于1898年，是戊戌变法的产物，也是中华民族救亡图存、兴学图强的结果，初名京师大学堂，是中国近现代第一所国立综合性大学，辛亥革命后，于1912年改为现名。')]
'''
