#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/1/4 15:06
@File    : _02_chat_llm.py
@Function :
"""
import os

from langchain.chat_models import init_chat_model
from langchain.messages import HumanMessage
from langchain_openai import ChatOpenAI

# 1. 使用ChatTongyi类
llm = init_chat_model(
    model="qwen-flash",
    api_key=os.getenv("API_KEY"),
    base_url=os.getenv("BASE_URL"),
    model_provider="openai",
)
# 2. 使用ChatOpenAI类
# llm = ChatOpenAI(
#     model="qwen-flash",
#     api_key=os.getenv('API_KEY'),
#     base_url=os.getenv("BASE_URL"),
# )
messages = [HumanMessage(content="给我说说一夜暴富有哪些方法")]
# 全文输出
response = llm.invoke(messages)
print(response.content)

# 流式输出
for chunk in llm.stream("你是什么模型"):
    print(chunk.content, end="")
