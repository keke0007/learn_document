#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/1/4 15:18
@File    : _03_embedding.py
@Function :
"""
import os

from langchain_community.embeddings import DashScopeEmbeddings

# 1. 使用DashScopeEmbeddings类
llm = DashScopeEmbeddings(
    model="text-embedding-v1",  # text-embedding-v3
    dashscope_api_key=os.getenv('API_KEY')
)

print(llm.embed_query("AI好啊，得学啊"))
print(llm.embed_documents(["AI好啊，得学啊", "hello world"]))

# from langchain.embeddings import init_embeddings

# 2. 使用init_embeddings函数
# 只支持部分官方调用，其余模型请使用langchain_community.embeddings

# llm = init_embeddings(
#     model="text-embedding-v1",  # text-embedding-v3
#     api_key=os.getenv('API_KEY'),
#     base_url=os.getenv("BASE_URL"),
# )

# print(llm.embed_query("AI好啊，得学啊"))
# print(llm.embed_documents(["AI好啊，得学啊", "hello world"]))
