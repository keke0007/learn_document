#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/1/4 14:42
@File    : _01_llm.py
@Function :
"""
import os
from langchain_community.llms import Tongyi

llm = Tongyi(
    api_key=os.getenv("API_KEY"),
    base_url=os.getenv("BASE_URL"),
    model="qwen-flash"
)

# 全文输出
# print(llm.invoke("给我说说一夜暴富有哪些方法"))
print(llm.invoke("hello"))

# 流式输出
for chunk in llm.stream("你是什么模型"):
    print(chunk, end="", flush=True)
