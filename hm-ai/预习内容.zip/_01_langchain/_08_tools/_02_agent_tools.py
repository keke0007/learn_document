#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/1/4 16:49
@File    : _09_agent_tools.py
@Function :
"""
from langchain.tools import tool
from langchain_openai import ChatOpenAI
import os
from langchain.agents import create_agent


@tool
def write_file(file_path: str, content: str) -> str:
    """
    把content写入文件路径file_path
    """
    with open(file_path, "w") as writer:
        writer.write(content)

    print(f"写入文件{file_path} 成功")


@tool
def multiply(a: int, b: int) -> int:
    """用于计算两个整数的乘积。"""
    print(f"正在执行乘法: {a} * {b}")
    return a * b


@tool
def add(a: int, b: int) -> int:
    """用于计算两个整数的乘积。"""
    print(f"正在执行加法: {a} * {b}")
    return a + b


llm = ChatOpenAI(
    model="qwen-flash",
    api_key=os.getenv('API_KEY'),
    base_url=os.getenv("BASE_URL"),
)

tools = [write_file, add, multiply]

agent = create_agent(
    model=llm,
    tools=tools,
    system_prompt="你是系统助手，需要根据用户的输入决定是否调用工具完成任务"
)

# print(agent.invoke({"input": "计算100加21的结果？"}))
# print(agent.invoke({"input": "解释下什么是注意力机制，写入当前目录下，文件名称自己起一个"}))
# print(agent.invoke({"input": "我已经问了几个问题？"}))  # 没有手动实现message功能
messages = [{"role": "user", "content": "计算100加21的结果？"}]
messages = agent.invoke({"messages": messages})
for each in messages["messages"]:
    print(each)
