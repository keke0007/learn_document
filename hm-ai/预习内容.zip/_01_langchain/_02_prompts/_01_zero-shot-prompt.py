#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author  : Vincent
@Time    : 2026/1/4 15:45
@File    : _04_zero-shot-prompt.py
@Function :
"""
from langchain_core.prompts import PromptTemplate
import os
from langchain_openai import ChatOpenAI

# 定义模板
template = "我的邻居姓{lastname}，他生了个儿子，给他儿子起个名字"

prompt = PromptTemplate(
    input_variables=["lastname"],
    template=template,
)

prompt_text = prompt.format(lastname="王")
print(prompt_text)
# result: 我的邻居姓王，他生了个儿子，给他儿子起个名字

llm = ChatOpenAI(
    model="qwen-flash",
    api_key=os.getenv('API_KEY'),
    base_url=os.getenv("BASE_URL"),
)

result = llm.invoke(prompt_text)
print(result.content)
