import os
from pyflink.common import Types
from pyflink.datastream import StreamExecutionEnvironment

# 设置环境变量
os.environ['JAVA_HOME'] = "/export/server/jdk1.8.0_241"
os.environ['FLINK_HOME'] = "/export/server/flink"

if __name__ == '__main__':
        # 1. 构建流式作业的运行环境
        env = StreamExecutionEnvironment.get_execution_environment()
        # 设置作业级别的全局并行度
        env.set_parallelism(1)

        # 2. 定义数据源
        input_ds = env.read_text_file("file:///export/data/word.txt")

        # 3. 数据处理
        result_ds = input_ds.flat_map(lambda x:x.split(" "))\
                .map(lambda word:(word, 1), output_type=Types.TUPLE([Types.STRING(), Types.INT()]))\
                .key_by(lambda x:x[0])\
                .reduce(lambda a, b:(a[0], a[1] + b[1]))

        # 4. 将处理数据保存到指定为止
        result_ds.print()

        # 5. 启动流式作业的运行
        env.execute()