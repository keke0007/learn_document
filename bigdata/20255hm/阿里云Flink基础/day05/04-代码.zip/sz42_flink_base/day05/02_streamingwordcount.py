import os

from pyflink.common import Types
from pyflink.datastream import StreamExecutionEnvironment, DataStream

# 设置环境变量
os.environ['JAVA_HOME'] = "/export/server/jdk1.8.0_241"
os.environ['FLINK_HOME'] = "/export/server/flink"

if __name__ == '__main__':
    # 1. 构建流式作业的运行环境
    env = StreamExecutionEnvironment.get_execution_environment()
    # 因为flink没有提供socket连接器，所以需要手动的指定连接器的地址，才可以使用连接器(Flink sql中才需要)
    # env.add_jars("file:///export/server/flink/lib/flink-examples-table_2.12-1.15.4.jar")
    # 设置作业级别的全局并行度
    env.set_parallelism(1)

    # 2. 定义数据源
    # pyflink没有提供直接访问socket的api，因此需要调用java的方法访问socketTextStream
    # flink会根据数据源是否支持流读还是批读决定运行流作业还是批作业（AUTO），如果数据源既可以流读也可以批读的时候需要手动指定读取方式
    input_ds = DataStream(env._j_stream_execution_environment.socketTextStream("172.19.131.250", 9999))

    # 3. 数据处理
    result_ds = input_ds.flat_map(lambda x: x.split(" ")) \
        .map(lambda word: (word, 1), output_type=Types.TUPLE([Types.STRING(), Types.INT()])) \
        .key_by(lambda x: x[0]) \
        .reduce(lambda a, b: (a[0], a[1] + b[1]))

    # 4. 将处理数据保存到指定为止
    result_ds.print()

    # 5. 启动流式作业的运行
    env.execute()