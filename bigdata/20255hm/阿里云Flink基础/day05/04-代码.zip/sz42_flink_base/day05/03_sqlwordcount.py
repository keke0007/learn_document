import os

from pyflink.common import Types
from pyflink.datastream import StreamExecutionEnvironment
from pyflink.table import StreamTableEnvironment

# 设置环境变量
os.environ['JAVA_HOME'] = "/export/server/jdk1.8.0_241"
os.environ['FLINK_HOME'] = "/export/server/flink"

if __name__ == '__main__':
    # 1. 构建流式作业的运行环境
    env = StreamExecutionEnvironment.get_execution_environment()
    t_env = StreamTableEnvironment.create(env)
    # 因为flink没有提供socket连接器，所以需要手动的指定连接器的地址，才可以使用连接器(Flink sql中才需要)
    env.add_jars("file:///export/server/flink/lib/flink-examples-table_2.12-1.15.4.jar")
    # 设置作业级别的全局并行度
    env.set_parallelism(1)

    # 2. 定义数据源
    t_env.execute_sql("""
        create table source_table (
            word string
            ) with (
            'connector' = 'socket',
            'hostname' = 'node1',
            'port' = '9999',
            'format' = 'csv'
        )
    """)

    # 3. 定义目标表数据源
    t_env.execute_sql("""
        create table sink_table (
            word string,
            cnt bigint
        ) with (
            'connector' = 'print'
        ) 
    """)

    # 4. 数据处理
    t_env.execute_sql("""
        insert into sink_table 
        select word,count(1) from source_table group by word
    """).wait()

    # 5. 启动流式作业的运行
    env.execute()