package cn.itcast.flink.day05;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;

/**
 * @author: itcast
 * @date: 2023/2/13 14:54
 * @desc: 需求：读取socket单词，进行词频统计。
 * 需要使用SQL来实现。
 */

public class SqlStreamingWordCount {
    public static void main(String[] args) throws Exception {
        //1.构建流式执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env);
        tEnv.getConfig().set("parallelism.default","1");

        //2.构建source表
        /**
         * 源表的schema
         *      |   word    |
         *      |   hello   |
         *      |   hive    |
         *      |   spark   |
         *      |   flink   |
         */

        tEnv.executeSql("create table source_table (" +
                "word string" +
                ") with (" +
                "'connector' = 'socket'," +
                "'hostname' = 'node1'," +
                "'port' = '9999'," +
                "'format' = 'csv'" +
                ")");


        //3.构建sink表
        /**
         * 目标表的schema：
         *      |   word    |   counts   |
         *      |   hello   |      1     |
         *      |   hive    |      1     |
         *      |   spark   |      1     |
         *      |   flink   |      1     |
         */
        tEnv.executeSql("create table sink_table (" +
                "word string," +
                "counts bigint" +
                ") with (" +
                "'connector' = 'print" +
                "')");


        //4.数据处理transformation
        tEnv.executeSql("insert into sink_table " +
                "select word,count(*) from source_table group by word").await();

        //5.启动流式任务
        env.execute();

    }
}
