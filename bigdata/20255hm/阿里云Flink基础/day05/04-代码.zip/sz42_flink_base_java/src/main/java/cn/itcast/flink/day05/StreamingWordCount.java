package cn.itcast.flink.day05;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

public class StreamingWordCount {
    /**
     * 定义主方法
     * @param args
     */
    public static void main(String[] args) throws Exception {
        // 1. 获取执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //设置并行度
        env.setParallelism(1);

        // 2. 获取数据源
        // 2.1 从文件读取数据
        DataStreamSource<String> input_ds = env.socketTextStream("172.19.131.250", 9999);

        // 3. 转换数据
        SingleOutputStreamOperator<String> flatMap_ds = input_ds.flatMap(new FlatMapFunction<String, String>() {
            /**
             * 实现flatMap方法
             * 样本：
             *  hadoop hadoop spark flink
             *  spark hadoop flink flink
             * @param value 传入值类型
             * @param out 输出类型
             * @throws Exception
             */
            @Override
            public void flatMap(String value, Collector<String> out) throws Exception {
                // 切割字符串
                String[] words = value.split(" ");
                for (String word : words) {
                    out.collect(word);
                }
            }
        });

        /**
         * 这里的string是输入值类型，是不可以改变的，他跟上一个数据集的存储的数据类型需要完全一致
         * Tuple2<String, Integer> 是一个元组，可以自定义数据类型, 元祖类型
         */
        SingleOutputStreamOperator<Tuple2<String, Integer>> map_ds = flatMap_ds.map(new MapFunction<String, Tuple2<String, Integer>>() {
            /**
             * 实现map方法
             * @param value 传入值类型
             * @return 返回值类型
             */
            @Override
            public Tuple2<String, Integer> map(String value) throws Exception {
                // 返回一个元组
                return new Tuple2<>(value, 1);
            }
        });

        /**
         * 输入值类型和返回值类型都是元祖对象
         */
        KeyedStream<Tuple2<String, Integer>, String> keyBy_ds = map_ds.keyBy(new KeySelector<Tuple2<String, Integer>, String>() {
            @Override
            public String getKey(Tuple2<String, Integer> value) throws Exception {
                // 返回元祖中的第一个值
                return value.f0;
            }
        });

        SingleOutputStreamOperator<Tuple2<String, Integer>> result = keyBy_ds.reduce(new ReduceFunction<Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> reduce(Tuple2<String, Integer> value1, Tuple2<String, Integer> value2) throws Exception {
                // 返回元祖中的第一个值
                return new Tuple2<>(value1.f0, value1.f1 + value2.f1);
            }
        });

        // 4. 打印结果
        result.print();

        // 5. 执行任务
        env.execute("BatchWordCount");
    }
}
