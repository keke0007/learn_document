package cn.itcast.flink.day05;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

import java.util.Arrays;

public class LamdaStreamingWordCount {
    public static void main(String[] args) throws Exception {
        // 1. 获取执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //设置并行度
        env.setParallelism(1);

        // 2. 获取数据源
        // 2.1 从文件读取数据
        DataStreamSource<String> input_ds = env.socketTextStream("node1", 9999);

        // 3. 转换数据
        SingleOutputStreamOperator<Tuple2<String, Integer>> result = input_ds.flatMap((String value, Collector<String> out) -> {
//            String[] words = value.split(" ");
//            for (String word : words) {
//                out.collect(word);
//            }
            Arrays.stream(value.split(" ")).forEach(out::collect);
        }).returns(Types.STRING).map((String value) -> {
            return Tuple2.of(value, 1);
        }).returns(Types.TUPLE(Types.STRING, Types.INT)).keyBy((Tuple2<String, Integer> value) -> {
            return value.f0;
        }).sum(1);

        // 4. 打印结果
        result.print();

        // 5. 执行任务
        env.execute("StreamingWordCount");
    }
}
