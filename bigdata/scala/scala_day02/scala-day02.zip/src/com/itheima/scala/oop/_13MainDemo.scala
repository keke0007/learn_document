package com.itheima.scala.oop

object _13MainDemo extends App {
  println("hello, scala")
}
