package com.itheima.scala.oop

object _12MainDemo {
  def main(args: Array[String]): Unit = {
    println("hello, scala")
  }
}
