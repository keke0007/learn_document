package com.itheima.scala.oop

object _01ClassObject {
  class Person{

  }

  def main(args: Array[String]): Unit = {
    val person = new Person()
    println(person)
  }
}
