package com.itheima.scala.oop

object _08ConstructorDemo {
  // 1. 定义Customer类
  // 2. 定义主构造器
  class Customer(var name:String = "", var address:String = "") {
    // 3. 定义辅助构造器
    def this(data:Array[String]) {
      this(data(0), data(1))
    }
  }

  // 4. 使用辅助构造器来创建对象
  def main(args: Array[String]): Unit = {
    val customer = new Customer(Array("张三", "北京"))

    println(customer.name)
    println(customer.address)
  }
}
