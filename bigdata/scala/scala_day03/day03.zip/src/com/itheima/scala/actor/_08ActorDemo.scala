package com.itheima.scala.actor

import scala.actors.{Actor, Future}

object _08ActorDemo {

  // 定义样例类封装数据
  case class Message(id:Int, message:String)
  case class ReplyMessage(message:String, name:String)

  // 1. 创建Actor，接收消息，回复消息
  object MsgActor extends Actor {
    override def act(): Unit = {
      loop {
        react {
          case Message(id, message) =>
            println(s"MsgActor接收到消息：${id}, ${message}")
            // 回复一个Reply消息
            sender ! ReplyMessage("我不好", "韩梅梅")
        }
      }
    }
  }

  // 2. 启动Actor，发送异步有返回消息
  def main(args: Array[String]): Unit = {
    MsgActor.start()

    // future表示将来会返回一个数据
    val future: Future[Any] = MsgActor !! Message(1, "你好")

    // 3. 获取打印返回消息
    // 3.1 提前通过一个循环等到future中有数据，再执行
    // 3.2 调用future.isSet方法就可以判断，数据是否已经被接收到
    while(!future.isSet) {}

    // 3.3 使用future的apply方法获取数据
    val replyMessagse = future.apply().asInstanceOf[ReplyMessage]
    println(s"接收到回复消息：${replyMessagse.message}, ${replyMessagse.name}")
  }

}
