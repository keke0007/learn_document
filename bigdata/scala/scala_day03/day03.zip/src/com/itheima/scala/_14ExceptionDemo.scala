package com.itheima.scala

object _14ExceptionDemo {
  def main(args: Array[String]): Unit = {
    // 抛出一个异常
    throw new Exception("这是一个异常!")
  }
}
