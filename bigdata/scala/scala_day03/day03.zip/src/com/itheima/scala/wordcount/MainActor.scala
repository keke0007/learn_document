package com.itheima.scala.wordcount

import java.io.File

import scala.actors.Future

object MainActor {
  def main(args: Array[String]): Unit = {
    // 1. 加载指定目录的文件列表
    // 1.1. 加载指定目录的数据文件
    val DIR_PATH = "./data/"
    // 获取到指定目录下的所有数据文件名
    val fileNameList = new File(DIR_PATH).list().toList

    // 1.2. 将数据文件添加上一个目录
    val fileDirNameList = fileNameList.map(DIR_PATH + _)

    // 1.3. 打印所有的文件名
    println(fileDirNameList)

    // 2. 创建Actor关联文件
    // 2.1. 创建Actor
    val wordCountActorList = fileNameList.map {
      fileName => new WordCountActor
    }

    // 2.2. 将Actor和文件名关联在一起
    val actorFileNameList: List[(WordCountActor, String)] = wordCountActorList.zip(fileDirNameList)

    println(actorFileNameList)

    // 3. 启动Actor/发送/接收消息
    val futureList = actorFileNameList.map {
      actorFileName =>
        val actor = actorFileName._1
        // 启动Actor
        actor.start()
        // 发送消息到Actor中，发送的是异步还有返回的消息
        val future: Future[Any] = actor !! WordCountTask(actorFileName._2)
        future
    }

    // 编写一个while循环来等待所有的Actor都已经返回数据
    while(futureList.filter(!_.isSet).size != 0) {}

    // 获取Future中封装的数据
    val wordCountResultList = futureList.map(_.apply().asInstanceOf[WordCountResult])

    // 获取样例类中封装的单词统计结果
    // List[Map(hadoop->3, spark->1), Map(hadoop->2, flink->1)]
    val wordCountResultMap: List[Map[String, Int]] = wordCountResultList.map(_.wordCountMap)

    // List[hadoop->3, spark->1, hadoop->2, flink->1]
    val resultList = WordCountUtil.reduce(wordCountResultMap.flatten)

    println(resultList)
  }
}
