package com.itheima.scala.generictype

object _03GenericType {
  // 1. 创建一个类和它的子类
  class Person
  class Student extends Person

  // 2. 创建一个泛型方法，并且给泛型方法指定一个上界
  def demo[T <: Person](array:Array[T]) = println(array)

  // 3. 使用不同的类型来调用泛型方法
  def main(args: Array[String]): Unit = {
    demo(Array(new Person))
    demo(Array(new Student))

    // 编译报错：String类型并不是Person类型或者是它的子类
    // demo(Array("hadoop"))
  }
}
