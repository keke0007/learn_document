package com.itheima.scala.wordcount

/**
  * 单词统计任务消息
  * @param fileName 文件名
  */
case class WordCountTask(fileName:String)

/**
  * 封装单词统计的结果
  * @param wordCountMap 单词-单词在某个文件中出现的数量
  */
case class WordCountResult(wordCountMap: Map[String, Int])