package com.itheima.scala

object _12RegexDemo {
  def main(args: Array[String]): Unit = {
    // 实现将邮箱列表转换为邮箱运营商名称列表
    // 1. 定义一个用于匹配邮箱的正则表达式（使用正则中的括号来进行分组）
    val regex = """.+@(.+)\..+""".r

    // 2. 定义一个邮箱列表
    val emlList = List("38123845@qq.com", "a1da88123f@gmail.com", "zhansan@163.com", "123afadff.com")

    // 3. 使用集合的函数式操作来进行转换
    val companyList = emlList.map {
      case eml@regex(company) => s"${eml} -> ${company}"
      case eml => s"${eml} -> 未知"
    }

    println(companyList)
  }
}
