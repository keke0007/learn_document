package com.itheima.scala.actor

import scala.actors.Actor

object _06ActorDemo {

  // 定义样例类封装消息
  case class ReplyMessage(message:String, name:String)

  // 1. 创建Actor，接收消息，回复消息
  object MsgActor extends Actor {
    override def act(): Unit = {
      loop {
        react {
          case Message(id, message) =>
            println(s"MsgActor接收到消息：${id}, ${message}")
            // 回复消息
            sender ! ReplyMessage("我不好", "张三")
        }
      }
    }
  }

  // 定义一个自定义消息
  case class Message(id:Int, message:String)

  // 2. 启动Actor，发送消息
  def main(args: Array[String]): Unit = {
    MsgActor.start()

    // 发送同步自定义消息
    val reply: Any = MsgActor !? Message(1, "你好")

    // 3. 打印回复消息
    if(reply.isInstanceOf[ReplyMessage]) {
      println(reply.asInstanceOf[ReplyMessage])
    }
  }

}
