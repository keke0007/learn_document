package com.itheima.scala.generictype

object _04GenericType {
  // 1. 定义类和子类
  class Person
  class Policeman extends Person
  class Superman extends Policeman

  // 2. 定义泛型方法，指定泛型的类型上下界
  def demo[T >: Policeman <: Person](array:Array[T]) = println(array)

  // 3. 调用demo方法，传入不同类型的数组进行测试
  def main(args: Array[String]): Unit = {
    demo(Array(new Person))
    demo(Array(new Policeman))
    // 编译报错：Superman并不是Policeman的父类
    // demo(Array(new Superman))
  }
}
