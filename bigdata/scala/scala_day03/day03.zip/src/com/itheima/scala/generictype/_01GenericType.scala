package com.itheima.scala.generictype

object _01GenericType {
  // 1. 定义一个方法获取数组的中间的元素
  def getMiddleEle[T](array:Array[T]) = array(array.length / 2)

  // 2. 调用该方法
  def main(args: Array[String]): Unit = {
    println(getMiddleEle(Array(1, 2, 3, 4, 5)))
    println(getMiddleEle(Array("a", "b", "c", "d", "e")))
    println(getMiddleEle(Array(1.0, 2.0, 3.0, 4.0, 5.0)))
  }
}
