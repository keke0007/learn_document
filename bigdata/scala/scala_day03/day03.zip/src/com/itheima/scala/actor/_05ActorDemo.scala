package com.itheima.scala.actor

import java.util.concurrent.TimeUnit

import scala.actors.Actor

object _05ActorDemo {
  // 1. 创建两个Actor
  // ActorSender--每隔一秒发送一个消息
  // ActorReceiver--不停地接收消息
  object ActorSender extends Actor {
    override def act(): Unit = {
      while(true) {
        // 发送异步消息
        ActorReceiver ! "你好"
        TimeUnit.SECONDS.sleep(1)
      }
    }
  }

  object ActorReceiver extends Actor {
    override def act(): Unit = {
      // 使用loop+react来复用线程，提高执行效率
      loop{
        react {
          case msg:String => println(msg)
        }
      }
    }
  }

  // 2. 启动Actor测试
  def main(args: Array[String]): Unit = {
    ActorSender.start()
    ActorReceiver.start()
  }
}
