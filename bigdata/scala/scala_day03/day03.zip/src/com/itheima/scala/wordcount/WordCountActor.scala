package com.itheima.scala.wordcount

import scala.actors.Actor
import scala.io.Source

class WordCountActor extends Actor{
  override def act(): Unit = {
    loop {
      react{
        case WordCountTask(fileName) =>
          println("接收到任务：对" + fileName + "进行单词统计")

          // 1. 读取文件，转换为列表
          // hadoop sqoop hadoop
          val lineList = Source.fromFile(fileName).getLines().toList

          // 2. 切割字符串，转换成一个一个的单词
          // [hadoop, sqoop, hadoop]
          val wordList: List[String] = lineList.flatMap(_.split(" "))

          // 3. 将单词转换为一个元组
          // [<hadoop,1>, <sqoop,1>, <hadoop,1>]
          val wordAndCountList: List[(String, Int)] = wordList.map(_ -> 1)

          // 4. 调用工具类方法来对单词元组列表进行分组、聚合
          val wordCountMap: Map[String, Int] = WordCountUtil.reduce(wordAndCountList)

          // 5. 打印测试
          println(wordCountMap)

          // 6. 将统计数据封装到一个样例类中，发送给MainActor
          sender ! WordCountResult(wordCountMap)
      }
    }
  }
}
