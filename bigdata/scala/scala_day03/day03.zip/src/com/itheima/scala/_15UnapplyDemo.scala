package com.itheima.scala

object _15UnapplyDemo {
  // 1. 定义一个普通的类
  class Student(var name:String, var age:Int)

  // 2. 实现unapply方法来定义提取器
  object Student {
    def unapply(student:Student) = {
      if(student != null) {
        // 返回一个Some封装数据
        Some(student.name, student.age)
      }
      else {
        None
      }
    }
  }

  // 3. 创建对象，使用模式匹配来提取值
  def main(args: Array[String]): Unit = {
    val zhangsan = new Student("张三", 20)

    zhangsan match {
      case Student(name, age) => println(s"${name}, ${age}")
    }
  }
}
