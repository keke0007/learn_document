package com.itheima.scala.actor

import scala.actors.Actor

object _07ActorDemo {
  // 1. 创建一个Actor，打印接收消息
  object MsgActor extends Actor {
    override def act(): Unit = {
      loop {
        react {
          case Message(message, company) => println(s"MsgActor接收到消息：${message}, ${company}")
        }
      }
    }
  }

  // 创建样例类封装消息
  case class Message(message:String, company:String)

  // 2. 启动Actor，给Actor发送异步无返回消息
  def main(args: Array[String]): Unit = {
    MsgActor.start()

    // 发送异步无返回消息
    MsgActor ! Message("您好，大爷，快交话费！", "中国联通")
  }
}
