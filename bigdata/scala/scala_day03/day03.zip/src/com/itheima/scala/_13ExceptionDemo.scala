package com.itheima.scala

object _13ExceptionDemo {
  def main(args: Array[String]): Unit = {
    // 使用try...catch来捕获异常
    try {
      val a = 10 / 0
    }
    catch {
      case ex:Exception => ex.printStackTrace()
    }

    println("程序继续执行")
  }
}
