package com.itheima.spark.worker

import com.typesafe.config.{Config, ConfigFactory}

object ConfigUtil {
  private val config: Config = ConfigFactory.load()

  val `worker.heartbeat.interval` = config.getInt("worker.heartbeat.interval")
}
