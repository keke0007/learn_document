package com.itheima.spark.worker

import akka.actor.{ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object Worker {
  def main(args: Array[String]): Unit = {
    val workerActorSystem = ActorSystem("workerActorSystem", ConfigFactory.load())
    val workerActor = workerActorSystem.actorOf(Props(WorkerActor), "workerActor")
  }
}
