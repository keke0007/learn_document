package com.itheima.spark.worker

import java.util.UUID

import akka.actor.{Actor, ActorSelection}
import com.itheima.spark.common.{RegisterSuccessMessage, WorkerHeartBeatMessage, WorkerRegisterMessage}

import scala.util.Random

object WorkerActor extends Actor{

  private var masterActorRef:ActorSelection = _
  private var workerid:String = _
  private var cpu:Int = _
  private var mem:Int = _
  private val CPU_LIST = List(1,2,3,4,6,8)
  private val MEM_LIST = List(512,1024,2048,4096)

  // 在Actor启动之前就会执行的一些代码
  // 放在preStart中
  override def preStart(): Unit = {
    // 1. 获取到MasterActor的引用
    val masterActorPath = "akka.tcp://masterActorSystem@127.0.0.1:7000/user/masterActor"
    masterActorRef = context.actorSelection(masterActorPath)

    // 2. 构建注册消息
    workerid = UUID.randomUUID().toString
    val r = new Random()
    cpu = CPU_LIST(r.nextInt(CPU_LIST.length))
    mem = MEM_LIST(r.nextInt(MEM_LIST.length))
    val registerMessage = WorkerRegisterMessage(workerid, cpu, mem)

    // 3. 发送消息给MasterActor
    masterActorRef ! registerMessage
  }

  override def receive: Receive = {
    case RegisterSuccessMessage => {
      println("WorkerActor：接收到注册成功消息")

      // 导入时间单位隐式转换
      import scala.concurrent.duration._
      // 导入隐式参数
      import context.dispatcher

      // 定时发送心跳消息给Master
      context.system.scheduler.schedule(0 seconds,
        ConfigUtil.`worker.heartbeat.interval` seconds) {
        masterActorRef ! WorkerHeartBeatMessage(workerid, cpu, mem)
      }
    }
  }
}
