package com.itheima.akka

import akka.actor.Actor

object MasterActor extends Actor{
  override def receive: Receive = {
    case "connect" => {
      println("MasterActor：接收到connect消息")
      // 获取发送者Actor的引用
      sender ! "success"
    }
  }
}
