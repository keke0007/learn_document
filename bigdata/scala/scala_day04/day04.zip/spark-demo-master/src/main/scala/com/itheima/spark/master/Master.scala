package com.itheima.spark.master

import akka.actor.{ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object Master {
  def main(args: Array[String]): Unit = {
    // 1. 构建ActorSystem
    val masterActorSystem = ActorSystem("masterActorSystem", ConfigFactory.load())

    // 2. 加载Actor
    val masterActor = masterActorSystem.actorOf(Props(MasterActor), "masterActor")

    // 3. 启动测试
  }
}
