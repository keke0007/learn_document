package com.itheima.spark.master

import com.typesafe.config.{Config, ConfigFactory}

object ConfigUtil {
  private val config: Config = ConfigFactory.load()

  // 配置检查Worker心跳的时间周期（秒）
  val `master.check.heartbeat.interval` = config.getInt("master.check.heartbeat.interval")
  // 配置Worker心跳超时的时间（秒）
  val `master.check.heartbeat.timeout` = config.getInt("master.check.heartbeat.timeout")
}
