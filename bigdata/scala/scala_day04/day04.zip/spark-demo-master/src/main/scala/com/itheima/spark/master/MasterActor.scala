package com.itheima.spark.master

import java.util.Date

import akka.actor.Actor
import com.itheima.spark.common.{RegisterSuccessMessage, WorkerHeartBeatMessage, WorkerInfo, WorkerRegisterMessage}

object MasterActor extends Actor{

  private val regWorkerMap = collection.mutable.Map[String,WorkerInfo]()

  override def preStart(): Unit = {
    // 导入时间单位隐式转换
    import scala.concurrent.duration._
    // 导入隐式参数
    import context.dispatcher

    // 1. 启动定时任务
    context.system.scheduler.schedule(0 seconds,
      ConfigUtil.`master.check.heartbeat.interval` seconds){
      // 2. 过滤大于超时时间的Worker
      val timeoutWorkerMap = regWorkerMap.filter {
        keyval =>
          // 获取最后一次心跳更新时间
          val lastHeartBeatTime = keyval._2.lastHeartBeatTime
          // 当前系统时间 - 最后一次心跳更新时间 > 超时时间（配置文件） * 1000，返回true，否则返回false
          if (new Date().getTime - lastHeartBeatTime > ConfigUtil.`master.check.heartbeat.timeout` * 1000) {
            true
          }
          else {
            false
          }
      }

      // 3. 移除超时Worker
      if(!timeoutWorkerMap.isEmpty) {
        regWorkerMap --= timeoutWorkerMap.map(_._1)

        // 4. 对Worker按照内存进行降序排序，打印Worker
        val workerList = regWorkerMap.map(_._2).toList
        val sortedWorkerList = workerList.sortBy(_.mem).reverse
        println("按照内存降序排序后的Worker列表：")
        println(sortedWorkerList)
      }
    }
  }

  override def receive: Receive = {
    case WorkerRegisterMessage(workerid, cpu, mem) => {
      println(s"MasterActor：接收到Worker注册消息${workerid}/${cpu}/${mem}")

      // 1. 保存worker信息（WorkerInfo）
      regWorkerMap += workerid -> WorkerInfo(workerid, cpu, mem, new Date().getTime)

      // 2. 回复一个注册成功消息
      sender ! RegisterSuccessMessage
    }
    case WorkerHeartBeatMessage(workerid, cpu, mem) => {
      println(s"MasterActor：接收到${workerid}心跳消息")

      regWorkerMap += workerid -> WorkerInfo(workerid, cpu, mem, new Date().getTime)
      println(regWorkerMap)
    }
  }
}
