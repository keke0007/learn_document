package com.itheima.akka.demo

import akka.actor.Actor

// 实现AkkaActor
object SenderActor extends Actor{
  // 在Actor并发编程模型，需要实现act，想要持续接收消息
  // loop + react
  // 但在akka编程模型中，直接在receive方法中编写偏函数直接处理消息就可以了
  override def receive: Receive = {
    case "start" => {
      println("SenderActor：接收到start消息")

      // 发送一个SubmitTaskMessage消息给ReceiverActor
      // akka://actorSystem的名字/user/actor的名字
      val receiverActor = context.actorSelection("akka://actorSystem/user/receiverActor")
      // 发送消息
      receiverActor ! SubmitTaskMessage("提交任务")
    }
    case SuccessSubmitTaskMessage(message) =>
      println(s"SenderActor：接收到任务提交成功消息 ${message}")
  }
}
