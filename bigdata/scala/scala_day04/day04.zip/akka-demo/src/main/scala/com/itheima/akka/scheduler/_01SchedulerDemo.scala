package com.itheima.akka.scheduler

import akka.actor.{Actor, ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object _01SchedulerDemo {
  // 1. 创建一个Actor，接收打印消息
  object ReceiveActor extends Actor {
    override def receive: Receive = {
      case x => println(x)
    }
  }

  // 2. 构建ActorSystem，加载Actor
  def main(args: Array[String]): Unit = {
    val actorSystem = ActorSystem("actorSystem", ConfigFactory.load())
    val receiveActor = actorSystem.actorOf(Props(ReceiveActor), "receiveActor")

    // 导入隐式转换
    import scala.concurrent.duration._
    // 导入隐式参数
    import actorSystem.dispatcher

    // 3. 定时发送消息给Actor
    // 3.1 延迟多久启动定时任务
    // 3.2 定时任务的周期
    // 3.3 指定发送消息给哪个Actor
    // 3.4 发送的消息是什么
    actorSystem.scheduler.schedule(0 seconds,
      1 seconds,
      receiveActor,
      "hello"
    )
  }

}
