package com.itheima.akka.demo

// 提交任务消息
case class SubmitTaskMessage(message:String)

// 提交任务成功消息
case class SuccessSubmitTaskMessage(message:String)
