package com.itheima.akka.scheduler

import akka.actor.{Actor, ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object _02SchedulerDemo {
  // 1. 创建Actor，接收打印消息
  object ReceiveActor extends Actor {
    override def receive: Receive = {
      case x => println(x)
    }
  }

  // 2. 构建ActorSystem，加载Actor
  def main(args: Array[String]): Unit = {
    val actorSystem = ActorSystem("actorSystem", ConfigFactory.load())
    val receiveActor = actorSystem.actorOf(Props(ReceiveActor), "receiveActor")

    // 导入隐式转换
    import scala.concurrent.duration._
    // 导入隐式参数
    import actorSystem.dispatcher

    // 3. 定时发送消息（自定义方式）
    actorSystem.scheduler.schedule(0 seconds, 1 seconds) {
      // 业务逻辑
      receiveActor ! "hello"
    }
  }

}
