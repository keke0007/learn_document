package com.itheima.akka.demo

import akka.actor.{ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object Entrance {
  def main(args: Array[String]): Unit = {
    // 1. 实现一个Actor trait
    // 2. 创建ActorSystem
    val actorSystem = ActorSystem("actorSystem", ConfigFactory.load())

    // 3. 加载Actor
    val senderActor = actorSystem.actorOf(Props(SenderActor), "senderActor")
    val receiverActor = actorSystem.actorOf(Props(ReceiverActor), "receiverActor")

    // 在main方法中，发送一个start字符串消息给SenderActor
    senderActor ! "start"
  }
}
