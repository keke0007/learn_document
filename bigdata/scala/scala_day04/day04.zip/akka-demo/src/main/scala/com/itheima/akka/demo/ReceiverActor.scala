package com.itheima.akka.demo

import akka.actor.Actor

object ReceiverActor extends Actor{
  override def receive: Receive = {
    case SubmitTaskMessage(message) => {
      println(s"ReceiverActor:接收到任务提交消息 ${message}")
      // 回复一个任务提交成功消息给SenderActor
      sender ! SuccessSubmitTaskMessage("成功提交任务")
    }
  }
}
