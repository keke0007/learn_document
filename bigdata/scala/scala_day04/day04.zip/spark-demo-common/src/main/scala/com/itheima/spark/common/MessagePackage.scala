package com.itheima.spark.common

// 封装Worker注册消息
// 1. wokerid
// 2. cpu核数
// 3. mem内存大小(M)
case class WorkerRegisterMessage(workerid:String,
                                 cpu:Int,
                                 mem:Int)

// 注册成功消息
case object RegisterSuccessMessage

// 心跳消息
case class WorkerHeartBeatMessage(workerid:String,
                                  cpu:Int,
                                  mem:Int)