package com.itheima.spark.common

// Worker基本信息
case class WorkerInfo(workerid:String,
                      cpu:Int,
                      mem:Int,
                      lastHeartBeatTime:Long)
