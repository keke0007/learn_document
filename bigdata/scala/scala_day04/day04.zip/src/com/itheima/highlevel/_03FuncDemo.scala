package com.itheima.highlevel

object _03FuncDemo {
  // 1. 定义一个方法（柯里化），计算两个Int类型的值
  def calculate(a:Int, b:Int)(calc:(Int, Int)=>Int) = {
    calc(a, b)
  }

  // 2. 调用柯里化方法
  def main(args: Array[String]): Unit = {
    println(calculate(1, 2)(_ + _))
    println(calculate(1, 2)(_ * _))
    println(calculate(1, 2)(_ - _))
  }
}
