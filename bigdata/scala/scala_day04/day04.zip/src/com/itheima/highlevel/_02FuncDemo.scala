package com.itheima.highlevel

object _02FuncDemo {
  def main(args: Array[String]): Unit = {
    // 使用匿名函数简化代码编写
    val startList = (1 to 10).map(x => "*" * x)
    println(startList)

    // 使用下划线来简化代码编写
    val starList2 = (1 to 10).map("*" * _)
    println(starList2)
  }
}
