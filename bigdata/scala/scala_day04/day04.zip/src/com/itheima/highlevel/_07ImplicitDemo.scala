package com.itheima.highlevel

object _07ImplicitDemo {
  // 1. 定义一个方法，这个方法有一个隐式参数
  def quote(what:String)(implicit delimeters:(String, String)) = {
    delimeters._1 + what + delimeters._2
  }

  // 2. 定义一个隐式参数
  object ImplicitDemo {
    implicit val delimeterParam = ("<<", ">>")
  }

  // 3. 调用方法执行测试
  def main(args: Array[String]): Unit = {
    import ImplicitDemo._

    println(quote("你好"))
  }
}
