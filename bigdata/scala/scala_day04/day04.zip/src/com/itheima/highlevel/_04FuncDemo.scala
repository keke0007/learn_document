package com.itheima.highlevel

object _04FuncDemo {
  def main(args: Array[String]): Unit = {
    val y = 10

    // 定义一个函数，访问函数作用域外部的变量
    val add: Int => Int = (x:Int) => x + y

    println(add(1))
  }
}
