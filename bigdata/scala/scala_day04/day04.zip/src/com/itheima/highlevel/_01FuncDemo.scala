package com.itheima.highlevel

object _01FuncDemo {
  def main(args: Array[String]): Unit = {
    // 1. 创建函数，将数字转换为小星星
    val func: Int => String = (num:Int) => "*" * num

    // 2. 创建列表，执行转换
    val starList = (1 to 10).map(func)

    // 3. 打印测试
    println(starList)
  }
}
